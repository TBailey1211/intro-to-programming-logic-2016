package edu.bailey.program5;

import java.util.Scanner;

/**
 *   FILENAME  :   LemonadeStand.java
 *   PURPOSE   :   To calculate individual sales for a lemonade stand.
 *   @author   :   Taylor Bailey
 */


public class LemonadeStand 
{//Start LemonadeStand

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);

		//Declare variables
				char product;
				char drinkSize;
				double drinkCost = 0.0;
				char cookieType;
				double COOKIE_COST = 0.75;
				char shirtType;
				double shirtCost = 0.0;
				
				int totalTransactions = 0;
				double totalSales = 0.0;
				int SMALL_OZ = 12;
				int MED_OZ = 16;
				
				int totalLemonade = 0;
				int totalChocolateChip = 0;
				int totalOatmeal = 0;
				int totalAutographed = 0;
				int totalNonAutographed = 0;

				char runProgram = ' ';
				
				//Welcome message
				System.out.println("Welcome to the Lemonade Stand sales calculation program!");
				System.out.println("Please enter your product type, first character only.");
				
				//Ask if the user wants to input a sale
				System.out.println("Please enter a Y if you want to input a sale or enter a N to quit.");
				runProgram = input.nextLine().charAt(0);
				runProgram = Character.toUpperCase(runProgram);
				
				// Check for a valid response of N or Y
				while (runProgram != 'N' && runProgram != 'Y')
				{
					System.out.printf("\n%s", "Invalid entry, please enter Y to calculate a sale or N to quit.");
					runProgram = input.nextLine().charAt(0);
					runProgram = Character.toUpperCase(runProgram);
				}
				
				while (runProgram == 'Y')
				{
				
					//Input product
					System.out.println("Enter a product or Q to quit.");
					System.out.println("L for Lemonade, C for Cookie, or S for T-Shirt.");
					product = input.nextLine().charAt(0);
					product = Character.toUpperCase(product);
				
					//If product is not one of the acceptable characters, get another!
					while (product != 'L' && product != 'C' && product != 'S' && product != 'Q')
					{
						System.out.println("Invalid input.");
						System.out.print("Enter a product or Q to quit (L,C,S,Q);: ");
						product = input.nextLine().charAt(0);
						product = Character.toUpperCase(product);
					}
				
				//If product is Lemonade
				if (product == 'L')
				{//Start Lemonade if
					System.out.println("Please input desired drink size (S for small (12 oz), M for Medium (16 oz), Q to quit).");
				    drinkSize = input.nextLine().charAt(0);
				    drinkSize = Character.toUpperCase(drinkSize);
				    
				  //If drinkSize is not one of the acceptable characters, get another!
					while (drinkSize != 'S' && drinkSize != 'M' && drinkSize != 'Q')
					{
						System.out.println("Invalid input.");
						System.out.print("Enter a drink size or Q to quit (S,M,Q).");
						drinkSize = input.nextLine().charAt(0);
						drinkSize = Character.toUpperCase(drinkSize);
					}
					
					//If drinkSize is Small
					if (drinkSize == 'S')
					{
						drinkCost = 1.50;
						//Count
						totalLemonade = totalLemonade + SMALL_OZ;
						totalSales = totalSales + drinkCost;
						//Display product and cost
						System.out.println("Item purchased:    12 Ounce Lemonade");
						System.out.printf("Item Price:    $%.2f%n", drinkCost);
					}
					else if (drinkSize == 'M')
					{
						drinkCost = 2.00;
						//Count
						totalLemonade = totalLemonade + MED_OZ;
						totalSales = totalSales + drinkCost;
						//Display product and cost
						System.out.println("Item purchased:   16 Ounce Lemonade");
						System.out.printf("Item Price:    $%.2f%n", drinkCost);
					}
					
				}//End Lemonade if
				
				//If product is Cookie
				else if (product == 'C')
				{//Start Cookie if
					System.out.println("Please input desired cookie type (C for Chocolate Chip, O for Oatmeal, Q for Quit).");
					cookieType = input.nextLine().charAt(0);
					cookieType = Character.toUpperCase(cookieType);
					
					 //If cookieType is not one of the acceptable characters, get another!
					while (cookieType != 'C' && cookieType != 'O' && cookieType != 'Q')
					{
						System.out.println("Invalid input.");
						System.out.print("Enter a cookie type or Q to quit (C,O,Q).");
						cookieType = input.nextLine().charAt(0);
						cookieType = Character.toUpperCase(cookieType);
					}
					
					if (cookieType == 'C')
					{
						//Count
						totalChocolateChip = totalChocolateChip + 1;
						totalSales = totalSales + COOKIE_COST;
						//Display product and cost
						System.out.println("Item purchased:   Chocolate Chip Cookie");
						System.out.printf("Item Price:   $%.2f%n", COOKIE_COST);
					}
					else if (cookieType == 'O')
					{
						//Count
						totalOatmeal = totalOatmeal + 1;
						totalSales = totalSales + COOKIE_COST;
						//Display product and cost
						System.out.println("Item purchased:   Oatmeal Cookie");
						System.out.printf("Item Price:   $%.2f%n", COOKIE_COST);
					}
					
				}//End Cookie if
				
				
				//If product is Shirt
				else if (product == 'S')
				{//Start Shirt if
					System.out.println("Please input the shirt type being purchased (A for autographed, R for regular, Q for Quit).");
					shirtType = input.nextLine().charAt(0);
					shirtType = Character.toUpperCase(shirtType);
					
					//If shirtType is not one of the acceptable characters, get another!
					while (shirtType != 'A' && shirtType != 'R' && shirtType != 'Q')
					{
						System.out.println("Invalid input.");
						System.out.print("Enter a shirt type or Q to quit (A,R,Q).");
						shirtType = input.nextLine().charAt(0);
						shirtType = Character.toUpperCase(shirtType);
					}
					
					//If shirtType is autographed
					if (shirtType == 'A')
					{
						shirtCost = 15.00;
						//Count
						totalAutographed = totalAutographed + 1;
						totalSales = totalSales + shirtCost;
						//Display product and cost
						System.out.println("Item purchased:   Autographed Shirt");
						System.out.printf("Item Price:   $%.2f%n", shirtCost);
					}
					else if (shirtType == 'R')
					{
						shirtCost = 8.00;
						//Count
						totalNonAutographed = totalNonAutographed +1;
						totalSales = totalSales + shirtCost;
						//Display product and cost
						System.out.println("Item purchased:   Non-Autographed Shirt");
						System.out.printf("Item Price:   $%.2f%n", shirtCost);
					}
					
				}//End Shirt if
				
				//Calculate transactions and sales
				totalTransactions = totalTransactions + 1;
				
				// Ask if the user wants to input another sale
				System.out.printf("Please enter Y if you want to input another sale or enter N to quit.");
				runProgram = input.nextLine().charAt(0);
				runProgram = Character.toUpperCase(runProgram);
				
				// Check for a valid response of N or Y
				while (runProgram != 'N' && runProgram != 'Y')
				{
					System.out.printf("\n%s", "Invalid entry, please enter Y to estimate a paycheck or N to quit.");
					runProgram = input.nextLine().charAt(0);
					runProgram = Character.toUpperCase(runProgram);
				}
		    		
		
			}//End while for runProgram
				
		//Display final values once the user chooses to stop inputting sales		
		if (runProgram == 'N')
		{
			System.out.println("Total Transactions    -   " + totalTransactions);
			System.out.printf("Total Sales    -    $%.2f%n", totalSales);
			System.out.println("Total Ounces of Lemonade Sold    -    " + totalLemonade);
			System.out.println("Total Chocolate Chip Cookies Sold    -    " + totalChocolateChip);
			System.out.println("Total Oatmeal Cookies Sold    -    " + totalOatmeal);
			System.out.println("Total Autographed T-Shirts Sold    -    " + totalAutographed);
			System.out.println("Total Non-Autographed T-Shirts Sold    -    " + totalNonAutographed);
		}
		
		System.out.println("Thank you for using the Lemonade Stand sales calculation program! Goodbye!");
				

	}//End LemonadeStand

}
