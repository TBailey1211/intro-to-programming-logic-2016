package edu.bailey.finalproject;

import java.util.Scanner;

/**
 *   FILENAME  :   CableTV.java
 *   PURPOSE   :   To calculate monthly cable service cost for customers as well as provide sales report.
 *   @author   :   Taylor Bailey
 */

public class CableTV {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		//Initialize variables
	    char runProgram = ' ';
	    char cablePackage = ' ';
	    double packagePrice = 0.0;
	    char highSpeedNet = ' ';
	    double highSpeedNetCost = 0.0;
	    char voiceOver = ' ';
	    double voiceOverCost = 0.0;
	    char discountResponse = ' ';
	    double planDiscount = 0.0;
	    double DISCOUNT = .02;
	    double finalPlanCost = 0.0;
	    int ecoplanTransactions = 0;
	    double ecoplanSales = 0.0;
	    int digitalPlanTransactions = 0;
	    double digitalPlanSales = 0.0;
	    int HDPlanTransactions = 0;
	    double HDPlanSales = 0.0;
	    int highSpeedNetTransactions = 0;
	    double highSpeedNetSales = 0.0;
	    int voiceOverTransactions = 0;
	    double voiceOverSales = 0;
	    int discountsGiven = 0;
	    
	    //Welcome message
	    System.out.println("Welcome to the ChaZConnect's service cost calculator!");
	    System.out.println("Would you like to begin by choosing your cableTV plan?");
	    System.out.println("Please enter Y to continue or N to quit.");
	    runProgram = input.nextLine().charAt(0);
		runProgram = Character.toUpperCase(runProgram);

		// Check for a valid response of N or Y
		while (runProgram != 'N' && runProgram != 'Y')
		{
			System.out.printf("Invalid entry, please enter Y to continue or N to quit.");
			runProgram = input.nextLine().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
		}
	    
		while (runProgram == 'Y')
		{//BEGIN MAIN METHOD
			
			//Get cable package
			cablePackage = getPackage();
			
			//Get price of package chosen
			packagePrice = getPackagePrice(cablePackage);
			
			//Cable package accumulators 
			if (cablePackage == 'A')
			{
				ecoplanTransactions = ecoplanTransactions + 1;
				ecoplanSales = ecoplanSales + packagePrice;
			}
			else if (cablePackage == 'B')
			{
				digitalPlanTransactions = digitalPlanTransactions + 1;
				digitalPlanSales = digitalPlanSales + packagePrice;
			}
			else if (cablePackage == 'C')
			{
				HDPlanTransactions = HDPlanTransactions +1;
				HDPlanSales = HDPlanSales + packagePrice;
			}
			
			System.out.println("ChaZConnect offers optional High Speed Internet and Voice Over IP services.");
			System.out.println("Would you like to sign up for a High Speed Internet (75 Mbps) plan for $29.99?");
			System.out.println("Enter Y or N.");
			highSpeedNet = input.nextLine().charAt(0);
			highSpeedNet = Character.toUpperCase(highSpeedNet);
			
			if (highSpeedNet == 'Y')
			{
				highSpeedNetTransactions = highSpeedNetTransactions + 1;
				highSpeedNetCost = 29.99;
				highSpeedNetSales = highSpeedNetSales + highSpeedNetCost;
			}
			
			System.out.println("Would you like to sign up for a Voice Over IP (75 Mbps) plan for $29.99?");
			System.out.println("Please enter Y or N.");
			voiceOver = input.nextLine().charAt(0);
			voiceOver = Character.toUpperCase(voiceOver);
			
			if (voiceOver == 'Y')
			{
				voiceOverTransactions = voiceOverTransactions + 1;
				voiceOverCost = 29.99;
				voiceOverSales = voiceOverSales + voiceOverCost;
			}
			
			System.out.println("You also have the option to process your payment automatically through credit or debit card.");
			System.out.println("Customers who choose this option will receive a 2% discount on their final monthly bill.");
			System.out.println("Would you like to opt for automatic payment?");
			System.out.println("Please enter Y or N.");
			discountResponse = input.nextLine().charAt(0);
			discountResponse = Character.toUpperCase(discountResponse);
			
			if (discountResponse == 'Y')
			{
				discountsGiven = discountsGiven + 1;
			}
			
			//Calculate plan cost
			finalPlanCost = packagePrice + highSpeedNetCost + voiceOverCost;
			
			//Calculate and display final plan to customer
			System.out.println("Here is your chosen monthly cableTV plan:");
			
			if (cablePackage == 'A')
			{
				System.out.println("Package  -  EcoPlan (45+channels)");
			}
			else if (cablePackage == 'B')
			{
				System.out.println("Package  -  DigitalPlan (140+channels)");
			}
			else if (cablePackage == 'C')
			{
				System.out.println("Package  -  HDPlan (220+channels)");
			}
			
			System.out.printf("Package price: $%.2f%n", packagePrice);
			System.out.printf("High Speed Internet:  $%.2f%n", highSpeedNetCost);
			
			System.out.printf("Voice Over IP:  $%.2f%n", voiceOverCost);
			
			if (discountResponse == 'Y')
			{
				planDiscount = finalPlanCost * DISCOUNT;
				finalPlanCost = finalPlanCost - planDiscount;
			}
			
			System.out.printf("Discount:  $%.2f%n", planDiscount);
			
			System.out.printf("Final plan cost:  $%.2f%n", finalPlanCost);
			
			 System.out.println("Would you like to calculate another plan?");
			 System.out.println("Please enter Y to continue or N to quit.");
			 runProgram = input.nextLine().charAt(0);
			 runProgram = Character.toUpperCase(runProgram);

			 // Check for a valid response of N or Y
			while (runProgram != 'N' && runProgram != 'Y')
			  {
				System.out.printf("Invalid entry, please enter Y to continue or N to quit.");
				runProgram = input.nextLine().charAt(0);
				runProgram = Character.toUpperCase(runProgram);
			  }
			
		}//END RUN PROGRAM
		
		if (runProgram == 'N')
		{
			System.out.println("====FINAL SALES REPORT====");
			System.out.println("Ecoplans sold:  " + ecoplanTransactions);
			System.out.printf("Ecoplan sales:  $%.2f%n", ecoplanSales);
			System.out.println("DigitalPlans sold:  " + digitalPlanTransactions);
			System.out.printf("DigitalPlan sales:  $%.2f%n", digitalPlanSales);
			System.out.println("HDPlans sold:  " + HDPlanTransactions);
			System.out.printf("HDPlan sales:  $%.2f%n", HDPlanSales);
			System.out.println("High Speed Internet Plans sold:  " + highSpeedNetTransactions);
			System.out.printf("High Speed Internet sales:  $%.2f%n", highSpeedNetSales);
			System.out.println("Voice Over IP Plans sold:  " + voiceOverTransactions);
			System.out.printf("Voice Over IP sales:  $%.2f%n", voiceOverSales);
			System.out.println("Discounts given:  " + discountsGiven);
		}

	}//END MAIN METHOD
	
	//Get cable package
	        /**
	        * Input cable package. Accept only A, B, or C.
	        * @return One of the three characters, shown above.
	        */
			public static char getPackage()
			{
				//Create a scanner object for input
				Scanner input = new Scanner(System.in);
				
				//Local variable to hold Menu Selection
				char aPackage = ' ';
				
				//Get cable package
				System.out.println("ChaZConnect offers three monthly cableTV plans:");
			    System.out.println("Ecoplan(45+ channels) - $19.99");
			    System.out.println("DigitalPlan(140+ channels) - $49.99");
			    System.out.println("HDPlan(220+ channels) - $59.99");
			    System.out.println("Which package would you like to select?");
			    System.out.println("A for Ecoplan.");
			    System.out.println("B for DigitalPlan.");
			    System.out.println("C for HDPlan.");
			    aPackage = input.nextLine().charAt(0);
				aPackage = Character.toUpperCase(aPackage);
			    
			    //If cable package is not one of the acceptable characters, get another!
			    if (aPackage != 'A' && aPackage != 'B' && aPackage != 'C')
			    {
			    	System.out.println("Invalid input.");
			    	System.out.println("Enter a valid cable package (A,B,C).");
			    	aPackage = input.nextLine().charAt(0);
					aPackage = Character.toUpperCase(aPackage);
			    }
			//Return cable package
			return aPackage;
    }//End getPackage
			
	//Get package price
			/**
			 * Calculates package price based on package selected
			 * @param aPackage for calculating aPackagePrice
			 * @return package price
			 */
			static double getPackagePrice(char aPackage)
			{
				//Create a scanner object for input
				Scanner input = new Scanner(System.in);
				
				//Local variable to hold package price
				double aPackagePrice = 0.0;
				
				//Get package price
				if (aPackage == 'A')
				{
					aPackagePrice = 19.99;
				}
				else if (aPackage == 'B')
				{
					aPackagePrice = 49.99;
				}
				else if (aPackage == 'C')
				{
					aPackagePrice = 59.99;
				}
			//Return package price
			return aPackagePrice;
	}//End getPackagePrice

}
