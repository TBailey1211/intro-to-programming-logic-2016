package edu.bailey.program6;

import java.util.Scanner;

/**
 *   FILENAME  :   LemonadeStand.java
 *   PURPOSE   :   To calculate individual sales for a lemonade stand.
 *   @author   :   Taylor Bailey
 */

public class LemonadeStand 
{//Start Main Method

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		//Declare variables
		char product = ' ';
		char drinkSize = ' ';
		double drinkCost = 0.0;
		char cookieType = ' ';
		double COOKIE_COST = 0.75;
		char shirtType = ' ';
		double shirtCost = 0.0;
		
		int totalTransactions = 0;
		double totalSales = 0.0;
		int SMALL_OZ = 12;
		int MED_OZ = 16;
		
		int totalLemonade = 0;
		int totalChocolateChip = 0;
		int totalOatmeal = 0;
		int totalAutographed = 0;
		int totalNonAutographed = 0;

		char runProgram = ' ';
		
		//Welcome message
		System.out.println("Welcome to the Lemonade Stand sales calculation program!");
		System.out.println("Please enter your product type, first character only.");
		
		//Ask if the user wants to input a sale
		System.out.println("Please enter a Y if you want to input a sale or enter a N to quit.");
		runProgram = input.nextLine().charAt(0);
		runProgram = Character.toUpperCase(runProgram);

		// Check for a valid response of N or Y
		while (runProgram != 'N' && runProgram != 'Y')
		{
			System.out.printf("\n%s", "Invalid entry, please enter Y to calculate a sale or N to quit.");
			runProgram = input.nextLine().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
		}

		while (runProgram == 'Y')
		{
			//Get Menu Selection
			product = getProduct();
			
			//Get Cup Size
			drinkSize = getDrinkSize(product);
			
			//Get Cup Price
			drinkCost = getDrinkCost(drinkSize);
			
			//Lemonade accumulators
			if (drinkSize == 'S')
			{
				//Count
				totalLemonade = totalLemonade + SMALL_OZ;
				totalSales = totalSales + drinkCost;
			}
			else if (drinkSize == 'M')
			{
				//Count
				totalLemonade = totalLemonade + MED_OZ;
				totalSales = totalSales + drinkCost;
			}
			
			//Get Cookie Type
			cookieType = getCookieType(product);
			
			//Get Shirt Type
			shirtType = getShirtType(product);
			
			//Get Shirt Price
			shirtCost = getShirtCost(shirtType);
			
			//Shirt accumulators 
			if (shirtType == 'A')
			{
				totalAutographed = totalAutographed + 1;
				totalSales = totalSales + shirtCost;
			}
			else if (shirtType == 'R')
			{
				//Count
				totalNonAutographed = totalNonAutographed +1;
				totalSales = totalSales + shirtCost;
			}
			
			//Get Cookie Type/Cost
			if (cookieType == 'C')
			{
				//Count
				totalChocolateChip = totalChocolateChip + 1;
				totalSales = totalSales + COOKIE_COST;

				//Display product and cost
				System.out.println("Item purchased:   Chocolate Chip Cookie");
				System.out.printf("Item Price:   $%.2f%n", COOKIE_COST);
			}
			else if (cookieType == 'O')
			{
				//Count
				totalOatmeal = totalOatmeal + 1;
				totalSales = totalSales + COOKIE_COST;

				//Display product and cost
				System.out.println("Item purchased:   Oatmeal Cookie");
				System.out.printf("Item Price:   $%.2f%n", COOKIE_COST);
			}
			
			//Calculate transactions and sales
			totalTransactions = totalTransactions + 1;

			// Ask if the user wants to input another sale
			System.out.printf("Please enter Y if you want to input another sale or enter N to quit.");
			runProgram = input.nextLine().charAt(0);
			runProgram = Character.toUpperCase(runProgram);
			
			// Check for a valid response of N or Y
			while (runProgram != 'N' && runProgram != 'Y')
			{
				System.out.printf("\n%s", "Invalid entry, please enter Y to input another sale or N to quit.");
				runProgram = input.nextLine().charAt(0);
				runProgram = Character.toUpperCase(runProgram);
			}

		} //End while for runProgram
		
		if (runProgram == 'N')
		{
			System.out.println("Total Transactions    -   " + totalTransactions);
			System.out.printf("Total Sales    -    $%.2f%n", totalSales);
			System.out.println("Total Ounces of Lemonade Sold    -    " + totalLemonade);
			System.out.println("Total Chocolate Chip Cookies Sold    -    " + totalChocolateChip);
			System.out.println("Total Oatmeal Cookies Sold    -    " + totalOatmeal);
			System.out.println("Total Autographed T-Shirts Sold    -    " + totalAutographed);
			System.out.println("Total Non-Autographed T-Shirts Sold    -    " + totalNonAutographed);
		}
		
		System.out.println("Thank you for using the Lemonade Stand sales calculation program! Goodbye!");

	}//End of main method

	//Get Menu Selection
	/**
	 * Input product. Accept only L, C, S, or Q
	 * @return One of the five characters, shown above
	 */
	public static char getProduct()
	{
		//Create a scanner object for input
		Scanner input = new Scanner(System.in);
		
		//Local variable to hold Menu Selection
		char aProduct = ' ';
		
		//Get Menu Selection
		System.out.println("Enter a product or Q to quit.");
		System.out.println("L for Lemonade, C for Cookie, or S for T-Shirt.");
		aProduct = input.nextLine().charAt(0);
		aProduct = Character.toUpperCase(aProduct);
	
		//If product is not one of the acceptable characters, get another!
		while (aProduct != 'L' && aProduct != 'C' && aProduct != 'S' && aProduct != 'Q')
		{
			System.out.println("Invalid input.");
			System.out.print("Enter a product or Q to quit (L,C,S,Q);: ");
			aProduct = input.nextLine().charAt(0);
			aProduct = Character.toUpperCase(aProduct);
		}
		//Return Menu Selection
		return aProduct;
	}//END MENU SELECTION
	
	//Get Cup Size
	/**
	 * Input Cup Size if Lemonade is selected. Accept only S, M, or Q
	 * @param aProduct to provide product selection
	 * @return Drink size desired
	 */
	public static char getDrinkSize(char aProduct)
	{
		//Create a scanner object for input
		Scanner input = new Scanner(System.in);
					
		//Local variable to hold Drink Size
		char aDrinkSize = ' ';

		if (aProduct == 'L')
		{
			System.out.println("Please input desired drink size (S for small (12 oz), M for Medium (16 oz), Q to quit).");
			aDrinkSize = input.nextLine().charAt(0);
			aDrinkSize = Character.toUpperCase(aDrinkSize);
			    
		//If drinkSize is not one of the acceptable characters, get another!
		while (aDrinkSize != 'S' && aDrinkSize != 'M' && aDrinkSize != 'Q')
		{
			System.out.println("Invalid input.");
			System.out.print("Enter a drink size or Q to quit (S,M,Q).");
			aDrinkSize = input.nextLine().charAt(0);
			aDrinkSize = Character.toUpperCase(aDrinkSize);
		}
	}//END IF
		   return aDrinkSize;	
  }//END DRINK SIZE
	
	//Get Cup Price
	/**
	 * Calculates cup price based on size selected 
	 * @param aDrinkSize for calculating aDrinkCost
	 * @return Drink cost
	 */
	static double getDrinkCost(char aDrinkSize)
	{
		//Create a scanner object for input
		Scanner input = new Scanner(System.in);
				
		//Local variable to hold Cup Price
		double aDrinkCost = 0.0;
				
		//Get Cup Price
		if (aDrinkSize == 'S')
		{
			aDrinkCost = 1.50;
			//Display product and cost
			System.out.println("Item purchased:    12 Ounce Lemonade");
			System.out.printf("Item Price:    $%.2f%n", aDrinkCost);
			}
			else if (aDrinkSize == 'M')
				{
				aDrinkCost = 2.00;
				//Display product and cost
				System.out.println("Item purchased:   16 Ounce Lemonade");
				System.out.printf("Item Price:    $%.2f%n", aDrinkCost);
				}
			//Return Drink Cost
			return aDrinkCost;
		} //END DRINK COST
		
	//Get Cookie Type
	/**
	 * Input cookie type desired. Accept only C, O, or Q
	 * @param aProduct to provide product selection
	 * @return Cookie type
	 */
	static char getCookieType(char aProduct)
	{
		//Create a scanner object for input
		Scanner input = new Scanner(System.in);
			
		//Local variable to hold Cookie Type
		char aCookieType = ' ';
			
		//Get Cookie Type
		if (aProduct == 'C')
			{//Start Cookie if
				System.out.println("Please input desired cookie type (C for Chocolate Chip, O for Oatmeal, Q for Quit).");
				aCookieType = input.nextLine().charAt(0);
				aCookieType = Character.toUpperCase(aCookieType);
				
				 //If cookieType is not one of the acceptable characters, get another!
				while (aCookieType != 'C' && aCookieType != 'O' && aCookieType != 'Q')
				{
					System.out.println("Invalid input.");
					System.out.print("Enter a cookie type or Q to quit (C,O,Q).");
					aCookieType = input.nextLine().charAt(0);
					aCookieType = Character.toUpperCase(aCookieType);
				}
		  }
			//Return Cookie Type
			return aCookieType;
	 }//END COOKIE TYPE
	
	//Get Shirt Type
	/**
	 * Input shirt type. Accept only A, R, or Q
	 * @param aProduct to provide product selection
	 * @return Shirt type
	 */
		static char getShirtType(char aProduct)
		{
			//Create a scanner object for input
			Scanner input = new Scanner(System.in);
			
			//Local variable to hold Shirt Type
			char aShirtType = ' ';
			
			//Get Shirt Type
			if (aProduct == 'S')
			{//Start Shirt if
				System.out.println("Please input the shirt type being purchased (A for autographed, R for regular, Q for Quit).");
				aShirtType = input.nextLine().charAt(0);
				aShirtType = Character.toUpperCase(aShirtType);
				
				//If shirtType is not one of the acceptable characters, get another!
				while (aShirtType != 'A' && aShirtType != 'R' && aShirtType != 'Q')
				{
					System.out.println("Invalid input.");
					System.out.print("Enter a shirt type or Q to quit (A,R,Q).");
					aShirtType = input.nextLine().charAt(0);
					aShirtType = Character.toUpperCase(aShirtType);
				}
		   }
			//Return Shirt Type
			return aShirtType;
    }//END SHIRT TYPE
		
		//Get Shirt Price
		/**
		 * Calculates the shirt cost once type is chosen
		 * @param aShirtType for calculating the correct cost
		 * @return Shirt cost 
		 */
		public static double getShirtCost(char aShirtType)
		{
			//Create a scanner object for input
			Scanner input = new Scanner(System.in);
			
			//Local variable to hold Shirt Price
			double aShirtCost = 0.0;
			
			//Get Shirt Cost
			if (aShirtType == 'A')
			{
				aShirtCost = 15.00;
				//Display product and cost
				System.out.println("Item purchased:   Autographed Shirt");
				System.out.printf("Item Price:   $%.2f%n", aShirtCost);
			}
			else if (aShirtType == 'R')
			{
				aShirtCost = 8.00;
				//Display product and cost
				System.out.println("Item purchased:   Non-Autographed Shirt");
				System.out.printf("Item Price:   $%.2f%n", aShirtCost);
			}
			//Return Shirt Cost
			return aShirtCost;
	}//END SHIRT COST

}
