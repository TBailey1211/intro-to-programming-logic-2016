package edu.bailey.program3;

import java.util.Scanner;

/**
 * FILENAME  :  PropertyLayout.java
 * PURPOSE   :  Calculate the layout and price of a property for the user
 * @author  :   Taylor Bailey
 */
public class PropertyLayout 
{

	public static void main(String[] args) 
	{ 
		Scanner input = new Scanner(System.in);
		
		//Declare variables
		double lotWidth = 0.0;
		double lotLength = 0.0;
		double houseWidth = 0;
		double houseLength = 0.0;
		double poolWidth = 0.0;
		double poolLength = 0.0;
		char sodType = ' ';
		double lotSquareFootage = 0.0;
		double houseSquareFootage = 0.0;
		double maximumPoolWidth = 0.0;
		double maximumPoolLength = 0.0;
		double poolSquareFootage = 0.0;
		double WIDTH_RESTRICTION = .50;
		double LENGTH_RESTRICTION = .75;
		double WATER_DEPTH = 6;
		double waterVolume = 0.0;
		double poolLaborCost = 0.0;
		double POOL_CONSTRUCTION = 18.95;
		double POOL_SYSTEMS = 1575.00;
		double finalPoolCost = 0.0;
		double sodSquareFootage = 0.0;
		double sodUnits = 0.0;
		double SQUARE_YARD = 9;
		double sodMaterialsCost = 0.0;
		double sodPrice = 0.0;
		double sodMinutes = 0.0;
		double SOD_PER_MIN = 3;
		double sodHours = 0.0;
		double SOD_PER_HOUR = 60;
		double sodLaborCost = 0.0;
		double SOD_LABOR = 6.95;
		double finalSodCost = 0.0;
		
		//Welcome message
		System.out.println("It is time to have a rectangular pool installed in your backyard! First, we'll need some dimensions.");
		//Ask property width
		System.out.println("What is the width of the property?");
		lotWidth = input.nextInt();
		
		//Ask property length
		System.out.println("What is the length of the property?");
		lotLength = input.nextInt();
		
		//Ask house width
		System.out.println("What is the width of the house?");
		houseWidth = input.nextInt();
		
		//Ask house length
		System.out.println("What is the length of the house?");
		houseLength = input.nextInt();
		
		//Ask sod type
		System.out.println("What type of sod are you purchasing? Choose from the following:");
		System.out.println("Type 'K' for Kentucky Bluegrass.");
		System.out.println("Type 'S' for South Carolina Rye.");
		input.nextLine();
		sodType = input.nextLine().charAt(0);
		sodType = Character.toUpperCase(sodType);
		
		//If statement for sod type
		if (sodType == 'K')
		{
			sodPrice = 1.47;
		}
		else
		{
			sodPrice = .57;	
		}//End if
		
		
		//Perform calculations
	    lotSquareFootage = lotWidth * lotLength;
	    houseSquareFootage = houseWidth * houseLength;
	    
	    maximumPoolWidth = WIDTH_RESTRICTION * lotWidth;
	    maximumPoolLength = LENGTH_RESTRICTION * lotWidth;
	    poolSquareFootage = maximumPoolWidth * maximumPoolLength;
	    waterVolume = WATER_DEPTH * maximumPoolWidth * maximumPoolLength;
	    poolLaborCost = (poolSquareFootage * POOL_CONSTRUCTION);
	    finalPoolCost = poolLaborCost + POOL_SYSTEMS;
	    
	    sodSquareFootage = lotSquareFootage - houseSquareFootage - poolSquareFootage;
	    sodUnits = sodSquareFootage / SQUARE_YARD;
	    sodMaterialsCost = sodUnits * sodPrice;
	    sodMinutes = sodUnits * SOD_PER_MIN;
	    sodHours = sodMinutes / SOD_PER_HOUR;
	    sodLaborCost = sodHours * SOD_LABOR;
	    finalSodCost = sodMaterialsCost + sodLaborCost;
			
		//Display final values
	    
	    System.out.println("Okay, here is an overview of the final dimensions and costs according to the information provided.");
	    System.out.printf("The property width is %.1f%n", lotWidth);
	    System.out.printf("The property length is %.1f%n", lotLength);
	    System.out.printf("The house width is %.1f%n", houseWidth);
	    System.out.printf("The house length is %.1f%n", houseLength);
	    System.out.printf("The property square footage is %.1f%n", lotSquareFootage);
	    System.out.printf("The house square footage is %.1f%n", houseSquareFootage);
	    System.out.printf("The sod square footage is %.1f%n", sodSquareFootage);
	    System.out.printf("The final cost of the sod is $%.2f%n", finalSodCost);
	    System.out.printf("The square footage of the pool is %.1f%n", poolSquareFootage);
	    System.out.printf("The final cost of the pool is $%.2f%n", finalPoolCost);
	    System.out.printf("The water volume of the pool is %.1f%n", waterVolume);
	    
	  //Else if statement for water volume
	  		if (waterVolume <= 3100)
	  		{
	  			System.out.println("The heater type needed is A");
	  		}
	  		else if (waterVolume <= 8000)
	  		{
	  			System.out.println("The heater type needed is B");
	  		}
	  		else if (waterVolume <= 15000)
	  		{
	  			System.out.println("The heater type needed is C");
	  		}
	  		else if (waterVolume <= 25000)
	  		{
	  			System.out.println("The heater type needed is D");
	  		}
	  		else if (waterVolume > 25000)
	  			System.out.println("The heater type needed is F");
	  		
	}

}
