package edu.bailey.program4;

import java.util.Scanner;

/**
 *   FILENAME  :   LemonadeStand.java
 *   PURPOSE   :   To calculate individual sales for a lemonade stand.
 *   @author   :    Taylor Bailey
 */

public class LemonadeStand 
{ //Start LemonadeStand
	
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		//Declare variables
		char product;
		char drinkSize;
		double drinkCost = 0.0;
		char cookieType;
		double COOKIE_COST = 0.75;
		char shirtType;
		double shirtCost = 0.0;
		
		//Welcome message
		System.out.println("Welcome to the Lemonade Stand sales calculation program!");
		System.out.println("Please enter your product type, first character only.");
		
		//Input product
		System.out.println("Enter a product or Q to quit.");
		System.out.println("L for Lemonade, C for Cookie, or S for T-Shirt.");
		product = input.nextLine().charAt(0);
		product = Character.toUpperCase(product);
		
		//If product is not one of the acceptable characters, get another!
		while (product != 'L' && product != 'C' && product != 'S' && product != 'Q')
		{
			System.out.println("Invalid input.");
			System.out.print("Enter a product or Q to quit (L,C,S,Q);: ");
			product = input.nextLine().charAt(0);
			product = Character.toUpperCase(product);
		}
		
		//If product is Lemonade
		if (product == 'L')
		{//Start Lemonade if
			System.out.println("Please input desired drink size (S for small (12 oz), M for Medium (16 oz), Q to quit).");
		    drinkSize = input.nextLine().charAt(0);
		    drinkSize = Character.toUpperCase(drinkSize);
		    
		  //If drinkSize is not one of the acceptable characters, get another!
			while (drinkSize != 'S' && drinkSize != 'M' && drinkSize != 'Q')
			{
				System.out.println("Invalid input.");
				System.out.print("Enter a drink size or Q to quit (S,M,Q).");
				drinkSize = input.nextLine().charAt(0);
				drinkSize = Character.toUpperCase(drinkSize);
			}
			
			//If drinkSize is Small
			if (drinkSize == 'S')
			{
				drinkCost = 1.50;
				//Display product and cost
				System.out.printf("Your 12 oz Lemonade will cost $%.2f%n", drinkCost);
			}
			else if (drinkSize == 'M')
			{
				drinkCost = 2.00;
				//Display product and cost
				System.out.printf("Your 16 oz Lemonade will cost $%.2f%n", drinkCost);
			}
			else if (drinkSize == 'Q')
			{//Begin if for Quit
				System.out.println("Thank you for using the Lemonade Stand sales calculation program. Goodbye!");
			}//End if for Quit

		}//End Lemonade if
		
		
		//If product is Cookie
		else if (product == 'C')
		{//Start Cookie if
			System.out.println("Please input desired cookie type (C for Chocolate Chip, O for Oatmeal, Q for Quit).");
			cookieType = input.nextLine().charAt(0);
			cookieType = Character.toUpperCase(cookieType);
			
			 //If cookieType is not one of the acceptable characters, get another!
			while (cookieType != 'C' && cookieType != 'O' && cookieType != 'Q')
			{
				System.out.println("Invalid input.");
				System.out.print("Enter a cookie type or Q to quit (C,O,Q).");
				cookieType = input.nextLine().charAt(0);
				cookieType = Character.toUpperCase(cookieType);
			}
			
			if (cookieType == 'C')
			{
				//Display product and cost
				System.out.printf("Your Chocolate Chip Cookie will cost $%.2f%n", COOKIE_COST);
			}
			else if (cookieType == 'O')
			{
				//Display product and cost
				System.out.printf("Your Oatmeal Cookie will cost $%.2f%n", COOKIE_COST);
			}
			
			else if (cookieType == 'Q')
			{//Begin if for Quit
				System.out.println("Thank you for using the Lemonade Stand sales calculation program. Goodbye!");
			}//End if for Quit
			
		}//End Cookie if
		
		
		//If product is Shirt
		else if (product == 'S')
		{//Start Shirt if
			System.out.println("Please input the shirt type being purchased (A for autographed, R for regular, Q for Quit).");
			shirtType = input.nextLine().charAt(0);
			shirtType = Character.toUpperCase(shirtType);
			
			//If shirtType is not one of the acceptable characters, get another!
			while (shirtType != 'A' && shirtType != 'R' && shirtType != 'Q')
			{
				System.out.println("Invalid input.");
				System.out.print("Enter a shirt type or Q to quit (A,R,Q).");
				shirtType = input.nextLine().charAt(0);
				shirtType = Character.toUpperCase(shirtType);
			}
			
			//If shirtType is autographed
			if (shirtType == 'A')
			{
				shirtCost = 15.00;
				//Display product and cost
				System.out.printf("Your autographed shirt will cost $%.2f%n", shirtCost);
			}
			else if (shirtType == 'R')
			{
				shirtCost = 8.00;
				//Display product and cost
				System.out.printf("Your non-autographed shirt will cost $%.2f%n", shirtCost);
			}
			
			else if (shirtType == 'Q')
			{//Begin if for Quit
				System.out.println("Thank you for using the Lemonade Stand sales calculation program. Goodbye!");
			}//End if for Quit
			
		}//End Shirt if
		
		if (product == 'Q')
		{//Begin if for Quit
			System.out.println("Thank you for using the Lemonade Stand sales calculation program. Goodbye!");
		}//End if for Quit
		
	}//End LemonadeStand

}
