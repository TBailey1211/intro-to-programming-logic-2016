package edu.bailey.program2;

import java.util.Scanner;

/**
 * FILENAME:    PropertyLayout.java
 * PURPOSE:     Calculate the dimensions of a property
 * @author     Taylor
 *
 */
public class PropertyLayout 
{ //Start PropertyLayout

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);

		//Declare and initialize all variables
		String userName = "";
		int lotLength = 0;
		int lotWidth = 0;
		int houseLength = 0;
		int houseWidth = 0;
		double POND_RESTRICTION = .85;
		double maxDiameter = 0;
		int desiredDiameter = 0;
		int desiredDepth = 0;
		double pondRadius = 0.0;
		int lotSquareFootage = 0;
		int houseSquareFootage = 0;
		double pondSquareFootage = 0.0;
		double sodSquareFootage = 0.0;
		double SOD_PRICE = 1.39;
		double sodCost = 0.0;

		//Gather userName, propertyLength, propertyWidth, houseLength, houseWidth
		System.out.println("Good afternoon! It is time to plan the layout of your new home. Can I get your first name?");
		userName = input.nextLine();
		
		System.out.println("Nice to meet you, " + userName);
		System.out.println("Now, I need some dimensions. What is the length of the property in feet?");
		lotLength = input.nextInt();
		
		System.out.println("What is the property width in feet?");
		lotWidth = input.nextInt();
		
		System.out.println("What is the house length in feet?");
		houseLength = input.nextInt();
		
		System.out.println("What is the house width in feet?");
		houseWidth = input.nextInt();
		
		//Calculate pond restriction
		maxDiameter = POND_RESTRICTION * lotWidth;
		maxDiameter = Math.floor(maxDiameter);
		
		//Display maxDiameter
		System.out.println("Okay, according to current zoning restrictions, the maximum diameter of a pond set into the back of the property cannot exceed 85% of the width of the property.");
		System.out.println("Given the dimensions you have provided, the pond must not exceed " + maxDiameter + " feet.");
		
		//Ask desiredDiameter, pondDepth
		System.out.println("What is the desired diameter of the pond?");
		desiredDiameter = input.nextInt();
		
		System.out.println("What should the pond's depth be?");
		desiredDepth = input.nextInt();
		
		//Calculate lotSquareFootage, houseSquareFootage, pondRadius, pondSquareFootage, sodSquareFootage, and sodCost
		lotSquareFootage = lotWidth * lotLength;
		houseSquareFootage = houseWidth * houseLength;
		pondRadius = desiredDiameter / 2;
		pondSquareFootage = Math.PI * (Math.pow(pondRadius, 2));
		sodSquareFootage = lotSquareFootage - houseSquareFootage - pondSquareFootage;
		sodCost = sodSquareFootage * SOD_PRICE;
		
		//Display all input and calculated values for user
		System.out.println("Okay, " + userName + " let's go over everything we have.");
		System.out.println("The length of the property is " + lotLength + " feet");
		System.out.println("The width of the property is " + lotWidth + " feet");
		System.out.println("The length of the house is " + houseLength + " feet");
		System.out.println("The width of the house is " + houseWidth + " feet");
		System.out.println("The desired diameter for the pond is " + desiredDiameter + " feet");
		System.out.println("The desired depth of the pond is " + desiredDepth + " feet");
		System.out.println("The square footage of the property is " + lotSquareFootage + " feet");
		System.out.println("The square footage of the house is " + houseSquareFootage + " feet");
		System.out.println("The square footage of the pond is " + pondSquareFootage + " feet");
		System.out.println("The sod square footage is " + sodSquareFootage + " feet");
		System.out.println("The cost of the sod is $" + sodCost);
		System.out.println("Hopefully this information will be beneficial to you in the construction of your new home!");
	}

} //End PropertyLayout
