package edu.bailey.midterm;

import java.util.Scanner;

/**
 * FILENAME    :    StateTuition.java
 * PURPOSE     :    To calculate tuition costs for students.
 * @author     :    Taylor Bailey
 **/

public class StateTuition 
{//Start StateTuition

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		//Declare variables
		char residency = ' ';
		int numberOfCredits = 0;
		double tuitionPerCredit = 0.0;
		double lotteryAssistance = 0.0;
		double LOTTERY_AMOUNT = 100.00;
		double basicTuition = 0.0;
		double finalTuition = 0.0;
		
		//Welcome message
		System.out.println("Welcome to the South Carolina Tuition Calculator!");
		System.out.println("Please enter your residency from the following choices:");
		
		//Input residency
		System.out.println("B for Berkeley");
		System.out.println("C for Charleston");
		System.out.println("D for Dorchester");
		System.out.println("E for South Carolina (outside of county)");
		System.out.println("F for out of state");
		residency = input.nextLine().charAt(0);
		residency = Character.toUpperCase(residency);
		
		//Determine tuition per credit
		if (residency == 'B' || residency == 'C' || residency == 'D')
		{
			tuitionPerCredit = 168.30;
		}
		else if (residency == 'E')
		{
			tuitionPerCredit = 186.30;
		}
		else if (residency == 'F')
		{
			tuitionPerCredit = 318.55;
		}
		
		
		//Input number of credits
		System.out.println("Please input the number of credits you have earned.");
		input.hasNextLine();
		numberOfCredits = input.nextInt();
		
		//Determine amount of lottery assistance granted
		if (numberOfCredits >= 6 && residency == 'B' || residency == 'C' || residency == 'D' || residency == 'E')
		{
			lotteryAssistance = LOTTERY_AMOUNT * numberOfCredits;
		}
		
		//Calculate basic tuition
		basicTuition = numberOfCredits * tuitionPerCredit;
		finalTuition = basicTuition - lotteryAssistance;
		
		//Display final values 
		if (residency == 'B' || residency == 'C' || residency == 'D')
		{
			System.out.println("Residency  -  Berkeley/Charleston/Dorchester");
		}
		else if (residency == 'E')
		{
			System.out.println("Residency  -  South Carolina outside of Berkeley/Charleston/Dorchester");
		}
		else if (residency == 'F')
		{
			System.out.println("Residency  -  Outside of the state of South Carolina");
		}
		
		System.out.println("Credits earned  -  " + numberOfCredits);
		System.out.printf("Tuition earned per credit  -  $%.2f%n", tuitionPerCredit);
		System.out.printf("Basic tuition before SC Lottery is applied  -  $%.2f%n", basicTuition);
		System.out.printf("Lottery assistance awarded  -  $%.2f%n", lotteryAssistance);
		System.out.printf("Final tuition  -  $%.2f%n", finalTuition);
	}

}
